#!/bin/bash

echo "Iniciando alteracao de IP"
sleep 1
cd /etc/netplan
sleep 1
echo "Realizando backup das configuracoes"
cp 00-installer-config.yaml 00-installer-config.yaml.bkp
sleep 3
echo "Removendo configuração atual"
rm 00-installer-config.yaml
sleep 5
cp config_ip 00-installer-config.yaml
sleep 3
echo "IP Configurado... Aguarde um momento por favor"
sleep 2
echo "Acesse o servidor após 10 segundos"
netplan apply
sleep 3
echo "Stop serviço SSH"
service ssh stop
sleep 3
echo "Start serviço SSH"
sleep 3
service ssh start
sleep 1

